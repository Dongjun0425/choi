import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Home'; // Home 컴포넌트 가져오기
import Signup from './Signup'; // 회원가입 컴포넌트 가져오기
import Login from './Login';
import Location from './Location';
import News from './News';

function App() {
  return (
      <Router>
          <Routes>
              <Route path="/" element={<Home />} /> {/* Home 페이지 경로 */}
              <Route path="/signup" element={<Signup />} /> {/* 회원가입 페이지 경로 */}
              <Route path="/login" element={<Login />} /> {/* 로그인 페이지 경로 */}
              <Route path="/Location" element={<Location />} />
              <Route path="/News" element={<News />} />
          </Routes>
      </Router>
  );
}

export default App;
