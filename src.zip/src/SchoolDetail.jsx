// SchoolDetail.jsx
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { parseStringPromise } from 'xml2js';
import axios from 'axios';
import './App.css';

const schoolData = {
  shingu: { name: "신구대학교", location: "성남시", rating: 3.1 },
  yongin: { name: "용인대학교", location: "용인시", rating: 3.7 },
  eastSeoul: { name: "동서울대학교", location: "성남시", rating: 3.5 },
  eulji: { name: "을지대학교", location: "성남시", rating: 3.1 },
  ict: { name: "ICT폴리텍대학", location: "광주시", rating: 3.8 },
  gachon: { name: "가천대학교", location: "성남시", rating: 3.4 }
};

const schoolIdMap = {
  shingu: '0000001',
  yongin: '0000002',
  eastSeoul: '0000003',
  eulji: '0000004',
  ict: '0000005',
  gachon: '0000006'
};

const tabNames = {
  news: '학교소식',
  review: '졸업생 리뷰',
  tuition: '등록금',
  scholarship: '장학금'
};

const SchoolDetail = () => {
  const { schoolId } = useParams();
  const school = schoolData[schoolId];
  const [tab, setTab] = useState("news");
  const [apiText, setApiText] = useState("데이터 불러오는 중...");

  useEffect(() => {
    const fetchData = async () => {
      if (!schoolIdMap[schoolId]) {
        setApiText("학교 ID를 찾을 수 없습니다.");
        return;
      }

      try {
        const schlId = schoolIdMap[schoolId];
        const response = await axios.get(
          `http://openapi.academyinfo.go.kr/openapi/service/rest/StudentService/getComparisonFreemhanChanceBalanceSelectionRatio?serviceKey=vdCZUaw0OvQ9OVGqD6P9%2B15oBKd6n%2FrVlXWRTS2Sj6uoLcYjEUsNBBZ5o7RJiCjWrTKezCptYyNzCOGJlUZSHg%3D%3D&pageNo=1&numOfRows=1&schlId=${schlId}&svyYr=2023`,
          { headers: { Accept: 'application/xml' } }
        );

        const result = await parseStringPromise(response.data);
        const item = result?.response?.body?.[0]?.items?.[0]?.item?.[0];
        const val = item?.indctVal1?.[0];

        setApiText(val ? `최종등록률: ${val}%` : "등록률 데이터 없음");
      } catch (err) {
        console.error("API 오류:", err);
        setApiText("데이터를 불러올 수 없습니다.");
      }
    };

    fetchData();
  }, [schoolId]);

  if (!school) return <div>학교 정보를 찾을 수 없습니다.</div>;

  return (
    <div style={{ padding: "40px", fontFamily: "sans-serif" }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "30px" }}>
        <div style={{ fontSize: "20px" }}>
          <span style={{ marginRight: "30px", fontWeight: "bold" }}>학교평가</span>
          <span style={{ marginRight: "30px", color: "#00bb66", fontWeight: "bold" }}>캠퍼스 랭킹</span>
          <span style={{ marginRight: "30px" }}>뉴스</span>
          <span>캠퍼스 위치</span>
        </div>
        <div>
          <span style={{ cursor: "pointer" }}>로그인</span>
          <span style={{ margin: "0 10px" }}>|</span>
          <span style={{ cursor: "pointer" }}>회원가입</span>
        </div>
      </div>

      <div style={{ background: "#dfffe2", padding: "20px", borderRadius: "10px", display: "flex", alignItems: "center", gap: "20px", marginBottom: "20px" }}>
        <div style={{ width: "100px", height: "100px", backgroundColor: "white", textAlign: "center", borderRadius: "10px" }}>
          <div style={{ fontSize: "20px", fontWeight: "bold", paddingTop: "20px" }}>학교이미지</div>
        </div>
        <div>
          <h2 style={{ margin: "0" }}>{school.name}</h2>
          <div style={{ color: "green" }}>★ {school.rating}</div>
        </div>
        <div style={{ marginLeft: "auto", width: "50%" }}>
          <input type="text" placeholder="학교를 검색해보세요." style={{ width: "100%", padding: "10px", fontSize: "16px", borderRadius: "10px", border: "1px solid lightgray" }} />
        </div>
      </div>

      <div style={{ display: "flex", gap: "40px", fontWeight: "bold", marginBottom: "20px", cursor: "pointer" }}>
        {Object.entries(tabNames).map(([key, label]) => (
          <span
            key={key}
            style={tab === key ? { color: "green", borderBottom: "2px solid green" } : {}}
            onClick={() => setTab(key)}
          >
            {label}
          </span>
        ))}
      </div>

      {tab === "news" && (
        <>
          <div style={{ display: "flex", gap: "20px" }}>
            <div style={{ flex: 1, backgroundColor: "#f8f8f8", borderRadius: "20px", padding: "20px", minHeight: "400px", textAlign: "center" }}>
              <h3>입학전형 최종등록률</h3>
              {apiText === "데이터 불러오는 중..." ? (
                <p style={{ fontSize: "18px", color: "#888" }}>📡 데이터를 불러오는 중입니다...</p>
              ) : (
                <p style={{ fontSize: "18px" }}>{apiText}</p>
              )}
              <p style={{ fontSize: "13px", color: "#555" }}>인문·사회 / 자연과학 / 예·체능 / 공학</p>
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: "20px", width: "250px" }}>
              <div style={{ backgroundColor: "#fff", border: "1px solid #ccc", borderRadius: "10px", padding: "10px" }}>
                한줄 리뷰 모음?
              </div>
              <div style={{ backgroundColor: "#fff", border: "1px solid #ccc", borderRadius: "10px", padding: "10px" }}>
                많이 검색한 검색어?
              </div>
            </div>
          </div>

          <div style={{ display: "flex", flexWrap: "wrap", marginTop: "20px", gap: "10px", padding: "20px", backgroundColor: "#f8f8f8", borderRadius: "20px" }}>
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} style={{ width: "30%", minWidth: "250px", border: "1px solid #ccc", borderRadius: "10px", padding: "15px", backgroundColor: "#fff" }}>
                <strong>통계 항목 {i + 1}</strong>
                <p style={{ fontSize: "13px", color: "#777" }}>데이터는 추후 API로 삽입 예정</p>
              </div>
            ))}
          </div>
        </>
      )}

      {tab === "review" && <div>졸업생 리뷰 내용입니다.</div>}
      {tab === "tuition" && <div>등록금 정보 내용입니다.</div>}
      {tab === "scholarship" && <div>장학금 정보 내용입니다.</div>}
    </div>
  );
};

export default SchoolDetail;