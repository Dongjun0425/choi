import React from 'react';

function GachonPage() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>가천대학교</h1>
      <p>가천대학교에 대한 상세 설명 페이지입니다.</p>
    </div>
  );
}

export default GachonPage;