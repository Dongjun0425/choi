// Home.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './App.css';
import eastSeoul from './img/eastSeoul.jpg';
import eulji from './img/eulji.jpg';
import gachon from './img/gachon.jpg';
import ict from './img/ict.jpg';
import shingu from './img/shingu.jpg';
import yongin from './img/yongin.jpg';

function Home() {
  const [selectedOption, setSelectedOption] = useState(""); // 선택된 드롭다운 옵션 상태
  const navigate = useNavigate(); // 페이지 이동을 위한 훅

  // 각 학교에 대한 정보 배열
  const Data = [
    { id: "shingu", title: "신구대학교", subtitle: "성남시", imgSrc: shingu },
    { id: "yongin", title: "용인대학교", subtitle: "용인시", imgSrc: yongin },
    { id: "eastSeoul", title: "동서울대학교", subtitle: "성남시", imgSrc: eastSeoul },
    { id: "eulji", title: "을지대학교", subtitle: "성남시", imgSrc: eulji },
    { id: "ict", title: "ICT폴리텍대학", subtitle: "광주시", imgSrc: ict },
    { id: "gachon", title: "가천대학교", subtitle: "성남시", imgSrc: gachon }
  ];

  return (
    <>
      {/* 상단 네비게이션 */}
      <div style={{ position: "relative", top: "-30px", left: "-60px", color: "black", textAlign: "left", margin: "0px", fontSize: "40px", fontWeight: "bold" }}>
        <span onClick={() => navigate("/")} style={{ cursor: "pointer" }}> 학교랭킹</span>
      </div>

      <div style={{ color: "black", paddingRight: "50px", display: "flex", justifyContent: "space-around", fontSize: "25px" }}>
        <span onClick={() => navigate("/ranking")} style={{ cursor: "pointer" }}>캠퍼스 랭킹</span>
        <span onClick={() => navigate("/news")} style={{ cursor: "pointer" }}>뉴스</span>
        <span onClick={() => navigate("/location")} style={{ cursor: "pointer" }}>캠퍼스 위치</span>
      </div>

      {/* 로그인/회원가입 */}
      <div style={{ position: "absolute", top: "0px", right: "0px", color: "black", textAlign: "right", margin: "0px", fontSize: "20px", padding: "10px" }}>
        <span onClick={() => navigate("/login")} style={{ cursor: "pointer" }}>로그인</span>
        <span> | </span>
        <span onClick={() => navigate("/signup")} style={{ cursor: "pointer" }}>회원가입</span>
      </div>

      {/* 검색창 */}
      <div style={{ marginTop: "40px", textAlign: "left", marginLeft: "70px" }}>
        <input
          id="searchInput"
          style={{ width: "1000px", height: "30px", padding: "20px", outline: "none", fontSize: "20px", border: "1px solid #000000", borderRadius: "10px" }}
          type="text"
          placeholder="학교를 검색해보세요."
          onKeyDown={(event) => {
            if (event.key === "Enter") {
              const searchQuery = event.target.value;
              if (searchQuery) navigate(`/search?query=${searchQuery}`);
            }
          }}
        />
      </div>

      {/* 필터 드롭다운 */}
      <div style={{ marginTop: "20px", textAlign: "left", marginLeft: "70px" }}>
        <select
          value={selectedOption}
          onChange={(e) => setSelectedOption(e.target.value)}
          style={{ padding: "10px", border: "1px solid #ccc", borderRadius: "5px", fontSize: "16px", width: "100px" }}
        >
          <option value="default" hidden>4년제</option>
          <option value="4년제">4년제</option>
          <option value="전문대">전문대</option>
        </select>

        <select
          value={selectedOption}
          onChange={(e) => setSelectedOption(e.target.value)}
          style={{ padding: "10px", border: "1px solid #ccc", borderRadius: "5px", fontSize: "16px", marginLeft: "10px", width: "100px" }}
        >
          <option value="default" hidden>지역</option>
          <option value="sungnam">성남</option>
          <option value="gwangju">광주</option>
        </select>

        <select
          value={selectedOption}
          onChange={(e) => setSelectedOption(e.target.value)}
          style={{ position: "absolute", right: "250px", fontSize: "15px", width: "80px", border: "none", borderBottom: "1px solid #000", padding: "5px" }}
        >
          <option value="default" hidden>정렬</option>
          <option value="latest">최신순</option>
          <option value="name">이름순</option>
        </select>
      </div>

      {/* 학교 목록 */}
      <div style={{ marginLeft: "50px" }}>
        <div style={{ display: "flex", width: "auto" }}>
          <ul
            style={{ display: "flex", flexDirection: "row", gap: "70px", marginLeft: "40px", padding: "0px", listStyle: "none", flexWrap: "wrap" }}
          >
            {Data.map((item) => (
              <li
                key={item.id}
                style={{ display: "flex", flexDirection: "column", alignItems: "center", marginTop: "30px", cursor: "pointer" }}
                onClick={() => navigate(`/school/${item.id}`)} // 상세 페이지로 이동
              >
                <div style={{ backgroundColor: "#ECECEC", borderRadius: "20px", padding: "20px", textAlign: "center", width: "240px", boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)" }}>
                  <img
                    src={item.imgSrc}
                    alt={item.title}
                    style={{ width: "240px", height: "240px", borderRadius: "20px" }}
                  />
                  <h2 style={{ fontSize: "20px", fontWeight: "bold", margin: "0", textAlignLast: "left" }}>{item.title}</h2>
                  <p style={{ fontSize: "15px", margin: "5px 0 0 0", textAlign: "left" }}>{item.subtitle}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </>
  );
}

export default Home;
