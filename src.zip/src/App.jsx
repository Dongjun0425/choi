import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Home';
import Signup from './Signup';
import Login from './Login';
import Location from './Location';
import News from './News';

// 각 학교별 상세 페이지 컴포넌트 import

import ShinguPage from './ShinguPage';
import YonginPage from './YonginPage';
import EastSeoulPage from './EastSeoulPage';
import EuljiPage from './EuljiPage';
import IctPage from './IctPage';
import GachonPage from './GachonPage';
import SchoolDetail from './SchoolDetail';


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/location" element={<Location />} />
        <Route path="/news" element={<News />} />
        <Route path="/school/:schoolId" element={<SchoolDetail />} />

        {/* 학교별 상세 페이지 */}
        <Route path="/Shingu" element={<ShinguPage />} />
        <Route path="/yongin" element={<YonginPage />} />
        <Route path="/eastSeoul" element={<EastSeoulPage />} />
        <Route path="/eulji" element={<EuljiPage />} />
        <Route path="/ict" element={<IctPage />} />
        <Route path="/gachon" element={<GachonPage />} />
      </Routes>
    </Router>
  );
}

export default App;
