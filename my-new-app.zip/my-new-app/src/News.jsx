import React from 'react'
import { useState } from 'react'
import reactLogo from './assets/react.svg'
import { useNavigate } from 'react-router-dom'
import viteLogo from '/vite.svg'
import './App.css'
import './Home.jsx'


function News() {
    const navigate = useNavigate();
    return (
        <>
         <div 
        style={{
        position : "relative",
          top: "-30px",
          left: "-60px",
          color: "black",
          textAlign: "left",
          margin: "0px",
          fontSize : "40px",
          fontWeight : "bold"
        }}>
         <span onClick={() => navigate(".")}
        style={{ cursor: "pointer" }}> 학교랭킹</span>
      </div>
    <div style={{
                color: "black",
                paddingRight : "50px",
                display : "flex",
                justifyContent : "space-around",
                fontSize : "25px",
                
                
            }}
>
        <span onClick={() => navigate("/ranking")}
        style={{ 
            cursor: "pointer" }}
            onMouseEnter={(e) =>  {(e.currentTarget.style.color = "#0000ff");
                (e.currentTarget.style.fontWeight = "bold")
            }}   
            onMouseLeave={(e) =>  {(e.currentTarget.style.color = "#000000");
                (e.currentTarget.style.fontWeight = "normal")
            }}> 캠퍼스 랭킹</span>
        <span onClick={() => navigate("/news")}
        style={{cursor: "pointer"}}  onMouseEnter={(e) =>  {(e.currentTarget.style.color = "#0000ff");
            (e.currentTarget.style.fontWeight = "bold")
        }}   
        onMouseLeave={(e) =>  {(e.currentTarget.style.color = "#000000");
            (e.currentTarget.style.fontWeight = "normal")
        }}>뉴스</span>
        <span onClick={() => navigate("location")}
        style={{
            cursor: "pointer",
            color : "#0000ff",
            fontWeight : "bold"}} 
        >캠퍼스 위치</span>
    </div>

    <div
    style={{
        position: "absolute", 
        top: "0px",
        right: "0px", 
        color: "black",
        textAlign: "right",
        margin: "0px",
        fontSize: "20px",
        padding: "10px"
    }}
>
     <span onClick={() => navigate("/login")}
        style={{cursor:"pointer"}}>로그인</span>
     <span> | </span>
     <span onClick={() => navigate("/signup")}
        style={{cursor:"pointer"}}>회원가입</span>
</div>

    </>
    )   
      
  }

  
  export default News;
  