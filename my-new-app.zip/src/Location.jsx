
import React, { useState, useEffect } from 'react';
import reactLogo from './assets/react.svg'
import { useNavigate } from 'react-router-dom'
import viteLogo from '/vite.svg'
import './App.css'
import './Home.jsx'

function Location() {
  useEffect(() => {
    const script = document.createElement('script');
    script.src = '//dapi.kakao.com/v2/maps/sdk.js?appkey=d52daa1c41c07f80810fbc61eca944d3&autoload=false';
    script.async = true;
    

    script.onload = () => {
      window.kakao.maps.load(() =>{
      const container = document.getElementById('map');
      const options = {
        center: new kakao.maps.LatLng(33.450701, 126.570667),
        level: 3,
      };
      const map = new kakao.maps.Map(container, options);

      const markerPosition = new window.kakao.maps.LatLng(33.450701, 126.570667);

      const marker = new window.kakao.maps.Marker({
        position : markerPosition,
      });

      marker.setMap(map);

      const infowindow = new window.kakao.maps.InfoWindow({
        content : '<div style = "padding:5px; font-size:14px;">여기는 제주도입니다.</div>',
      });

      window.kakao.maps.event.addListener(marker,'click',function() {
        infowindow.open(map,marker);
    });
    window.kakao.maps.event.addListener(map,'click',function() {
      infowindow.close();
  });
      });
    };

    document.head.appendChild(script);
  },[]);

  return (
    <div style={{
        position : "relative",
        height :"700px"
    }}>
      <div style={{
        width : "520px",
        display : "flex",
        justifyContent : "flex-end"
      }}>
        <h2 style={{
          paddingTop : "50px"
        }}>캠퍼스 위치</h2>
      </div>

    <div id="map" style={{
      width: '600px',
      height: '500px',
      border : "1px solid #000",
      borderRadius : "20px",
      position : "absolute",
      top : "120px",
      left : "400px"}}></div>
    
    </div>
  );
}

export default Location;
  