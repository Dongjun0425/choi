import reactLogo from './assets/react.svg'
import { useNavigate } from 'react-router-dom'
import React, { useState, useEffect } from 'react';
import viteLogo from '/vite.svg'
import './App.css'
import './Home.jsx'
import shingu from './img/shingu.jpg';
import yongin from './img/yongin.jpg';



function News() {
    const navigate = useNavigate();
    const [newsData, setNewsData] = useState([]);
   useEffect(() => {
       // 실제 API 호출 코드는 여기에 작성합니다.
       // 예시로 setTimeout을 사용하여 비동기 데이터 로딩을 흉내냅니다.
       setTimeout(() => {
         const fetchedNewsData = [
           {
             schoolName: "신구대학교",
             newsTitle: "신구대학교 장학금 지원제도",
             newsContent: "장학금 지급 제한 정학이상의 징계를\n\n 받은 학생 학생 신분에 어긋난 행동을 하였을 경우 장학",
             imageUrl: shingu // 이미지 URL 또는 import한 이미지
           },
           {
             schoolName: "용인대학교",
             newsTitle: "용인대학교 장학금 지원제도",
             newsContent: "장학금 지급 제한 정학이상의 징계를 받은 학생, 학생 신분에 어긋난 행동을 하였을 경우 장",
             imageUrl: yongin // 다른 이미지 URL
           },
         ];
         setNewsData(fetchedNewsData);
       }, 100); // 100ms 후에 데이터 설정 (실제 API 호출은 Promise 등을 사용)
     }, []);
    return (
        <>
 

 <div style={{
                    fontSize : "20px",
                    textAlign : "left",
                    fontWeight :"bold"}}>최신뉴스</div>
            <div> 
        {newsData.map((data, index) => (
          <div key={index} style={{ 
            display: 'flex', 
            alignItems: 'flex-start', 
            width: '100px',
            marginLeft : "200px",
            marginBottom : "40px"
             }}>
            <div style={{
              display: "flex",
              justifyContent: "flex-end",
              width: "400px"
            }}>
              <img
                src={data.imageUrl}
                style={{
                  width: "200px",
                  height: "160px",
                  borderRadius: "20px",
                  justifyContent: "right",
                  cursor : "pointer",
                  marginBottom : "0px"
                }}
                alt={data.schoolName}
                onClick={() => navigate(data.schoolName)}
              />
            </div>
            <div style={{
              display: "flex",
              width: "1000px",
              flexDirection : "column",
              textAlign : "left",

            }}>
              <p style={{
                marginLeft: "30px",
                fontSize: "30px",
                fontWeight: "bold",
                width: "700px",
                textAlign: "left",
                cursor : "pointer",
                marginBottom : "10px"
              }} onClick={() => navigate(data.schoolName)}>
                {data.newsTitle}
                <p style={{
                  fontSize: "15px",
                  fontWeight: "normal",
                  whiteSpace: "pre-line",
                  cursor : "pointer",
                  marginTop  : "20px",
                  lineHeight : "15px"
                }} onClick={() => navigate(data.schoolName)}>
                  {data.newsContent}
                </p>
              </p>
            </div>
          </div>
        ))}
      </div>


 
    </>
    )   
      
  }

  
  export default News;
  