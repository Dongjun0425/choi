import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import EmotionService from './services/EmotionService';
import Home from './Home'; // Home 컴포넌트 가져오기
import Signup from './Signup'; // 회원가입 컴포넌트 가져오기
import Login from './Login';
import Location from './Location';
import News from './News';
import Ranking from './Ranking';
import Footer from './footer';
import Header from './Header';
import All3 from './All3';
import All4 from './All4';
import KakaoLogin from './KakaoLogin';

function App() {
  useEffect(() => {
    EmotionService.getEmotions()
      .then(response => console.log(response.data))
      .catch(error => console.error(error));
  }, []);
  return (
      <Router>
        <Header />
          <Routes>
              <Route path="/" element={<Home />} /> {/* Home 페이지 경로 */}
              <Route path="/signup" element={<Signup />} /> {/* 회원가입 페이지 경로 */}
              <Route path="/login" element={<Login />} /> {/* 로그인 페이지 경로 */}
              <Route path="/Location" element={<Location />} />
              <Route path="/News" element={<News />} />
              <Route path='Ranking' element={<Ranking />} />
              <Route path='All3' element={<All3 />} />
              <Route path='All4' element={<All4 />} />
              <Route path='KakaoLogin' element = {<KakaoLogin/>} />
              <Route path="Footer" element={<Footer />} /> 
          </Routes>
          <Footer />
      </Router>
  );
}

export default App;
