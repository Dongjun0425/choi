// src/KakaoRedirectHandler.jsx
import React, { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';

function KakaoRedirectHandler() {
    const navigate = useNavigate();
    const location = useLocation();

    useEffect(() => {
        const queryParams = new URLSearchParams(location.search);
        const token = queryParams.get('token');

        if (token) {
            // ✅ 1. 토큰 로컬스토리지에 저장
            localStorage.setItem('token', token);

            // ✅ 2. 로그인 후 이동할 페이지로 리다이렉트
            navigate('/home'); // 또는 다른 경로
        } else {
            alert('로그인 실패: 토큰 없음');
            navigate('/login');
        }
    }, [location, navigate]);

    return <p>로그인 처리 중...</p>;
}

export default KakaoRedirectHandler;
