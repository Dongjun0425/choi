import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import './SchoolDetail.css';

const SchoolDetail = () => {
  const { schoolId } = useParams();
  const [school, setSchool] = useState(null);
  const [tab, setTab] = useState("news");
  const [reviews, setReviews] = useState([]);
  const [reviewInput, setReviewInput] = useState('');

  useEffect(() => {
    fetch(`http://localhost:8080/university/${schoolId}`)
      .then(res => res.json())
      .then(data => setSchool(data))
      .catch(err => console.error(err));
  }, [schoolId]);

  const renderReviewTab = () => (
    <div className="school-info-container review-box">
      <h3>졸업생 리뷰 작성</h3>
      <form onSubmit={e => {
        e.preventDefault();
        if (!reviewInput.trim()) return;
        setReviews([{ text: reviewInput, date: new Date() }, ...reviews]);
        setReviewInput('');
      }}>
        <input
          value={reviewInput}
          onChange={e => setReviewInput(e.target.value)}
          placeholder="리뷰를 입력하세요"
          maxLength={300}
        />
        <button type="submit">등록</button>
      </form>
      <h4>리뷰 목록</h4>
      <ul>
        {reviews.length === 0 && <li style={{ color: "#777" }}>아직 등록된 리뷰가 없습니다.</li>}
        {reviews.map((r, idx) => (
          <li key={idx}>
            <div>{r.text}</div>
            <div style={{ color: "#aaa", fontSize: 12 }}>{r.date.toLocaleString()}</div>
          </li>
        ))}
      </ul>
    </div>
  );

  if (!school) return <div style={{ padding: "40px" }}>학교 정보를 불러오는 중...</div>;

  return (
    <div style={{ padding: "40px", fontFamily: "sans-serif" }}>
      <div style={{
        display: "flex", gap: "40px", fontWeight: "bold",
        marginBottom: "20px", cursor: "pointer"
      }}>
        {["news", "review"].map(tabKey => (
          <span key={tabKey}
            style={tab === tabKey ? { color: "green", borderBottom: "2px solid green" } : {}}
            onClick={() => setTab(tabKey)}
          >
            {tabKey === "news" ? "학교정보" : "졸업생 리뷰"}
          </span>
        ))}
      </div>

      {tab === "news" && (
        <div className="school-info-container">
          <ul>
            <li><strong>학교명:</strong> {school.name}</li>
            <li><strong>위치:</strong> {school.location}</li>
            <li><strong>설립연도:</strong> {school.foundationYear}년</li>
            <li><strong>전화번호:</strong> {school.phoneNumber}</li>
            <li><strong>홈페이지:</strong> <a href={school.website} target="_blank" rel="noreferrer">{school.website}</a></li>
          </ul>
        </div>
      )}

      {tab === "review" && renderReviewTab()}
    </div>
  );
};

export default SchoolDetail;
