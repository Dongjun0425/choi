    import React from 'react';
    import { useNavigate } from 'react-router-dom';
    import './App.css';
    import './Home.jsx';
    import './Signup.jsx';

    function Login() {
        const navigate = useNavigate();

        const REST_API_KEY = 'a30d75a10ce209f44e0e8ec072688d53';
        const REDIRECT_URI = 'http://localhost:8080/oauth/kakao/callback';
        const KAKAO_AUTH_URL = `https://kauth.kakao.com/oauth/authorize?client_id=${REST_API_KEY}&redirect_uri=${REDIRECT_URI}&response_type=code&scope=profile_nickname`;

        const handleKakaoLogin = () => {
            window.location.href = KAKAO_AUTH_URL;
        };

        return (
            <>
                <div style={{
                    fontSize: "40px",
                    marginTop: "50px",
                    marginLeft: "300px",
                    border: "0.5px solid rgb(179, 174, 174)",
                    borderRadius: "20px",
                    padding: "100px 50px",
                    width: "50%",
                    position: "relative",
                }}>
                    <p style={{
                        position: "absolute",
                        top: "1px",
                        left: "350px",
                        marginTop: "20px"
                    }}>
                        로그인
                    </p>

                    {/* ✅ 카카오 로그인 버튼 */}
                    <button
                        onClick={handleKakaoLogin}
                        style={{
                            width: "72%",
                            height: "70px",
                            border: "none",
                            borderRadius: "10px",
                            backgroundColor: "#ffff00",
                            fontSize: "30px",
                            cursor: "pointer",
                        }}
                    >
                        카카오톡 로그인
                    </button>

                    <hr />

                    {/* 이메일 & 비밀번호 입력 */}
                    <div>
                        <input type='text' style={{
                            border: "1px solid #000000",
                            width: "70%",
                            marginBottom: "10px",
                            height: "50px",
                            borderRadius: "10px",
                            fontSize: "20px"
                        }} placeholder="이메일 주소" />

                        <input type='password' style={{
                            border: "1px solid #000000",
                            width: "70%",
                            marginBottom: "10px",
                            height: "50px",
                            borderRadius: "10px",
                            fontSize: "20px"
                        }} placeholder="비밀번호" />
                    </div>

                    {/* 아이디 저장 및 찾기 */}
                    <div style={{ display: "flex" }}>
                        <div style={{ marginLeft: "100px", marginTop: "-20px" }}>
                            <span style={{ fontSize: "15px" }}>
                                <input type='checkbox' style={{ border: "1px solid rgb(196, 188, 188)", borderRadius: "30px" }} />아이디저장
                            </span>
                        </div>
                        <div style={{ marginLeft: "240px", marginTop: "-20px" }}>
                            <span onClick={() => navigate("/findid")} style={{ cursor: "pointer", fontSize: "15px", marginRight: "20px" }}>아이디 찾기</span>
                            <span onClick={() => navigate("/findpw")} style={{ cursor: "pointer", fontSize: "15px", marginLeft: "-10px" }}>비밀번호 찾기</span>
                        </div>
                    </div>

                    {/* 회원가입 안내 */}
                    <div style={{ marginTop: "70px" }}>
                        <p style={{ fontSize: "18px", marginTop: "-30px" }}>
                            아직 회원이 아니세요?
                            <span onClick={() => navigate("/signup")} style={{ cursor: "pointer", fontSize: "15px", color: "#f234f0" }}> 회원가입</span>
                        </p>
                    </div>
                </div>
            </>
        );
    }

    export default Login;
