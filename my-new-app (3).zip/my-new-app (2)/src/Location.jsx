import React, { useState, useEffect } from 'react';

function Location() {
  const [universities, setUniversities] = useState([]);

  // 지도 초기화 함수
  const initMap = (universityData) => {
    const container = document.getElementById('map');
    const options = {
      center: new kakao.maps.LatLng(37.448868, 127.167653),
      level: 3
    };
    const map = new kakao.maps.Map(container, options);

    const infowindows = [];

    universityData.forEach(university => {
      const marker = new kakao.maps.Marker({
        position: university.position
      });
      marker.setMap(map);

      const infowindowContent = `
        <div style="padding:5px; font-size:14px; text-align:center; width: 180px;">
          <strong>${university.name}</strong><br/>
          <img src="${university.imageUrl}" alt="${university.name}" 
               style="width:160px; height:auto; margin-top:5px; border-radius:5px;"/>
        </div>
      `;

      const infowindow = new kakao.maps.InfoWindow({
        content: infowindowContent
      });
      infowindows.push(infowindow);

      window.kakao.maps.event.addListener(marker, 'click', function () {
        infowindows.forEach(info => info.close());
        infowindow.open(map, marker);
      });
    });

    // 지도 클릭 시 모든 infowindow 닫기
    window.kakao.maps.event.addListener(map, 'click', function () {
      infowindows.forEach(info => info.close());
    });
  };

  useEffect(() => {
    const fetchDataAndInitMap = () => {
      fetch('http://localhost:8080/university/all')
        .then(response => response.json())
        .then(data => {
          const mappedUniversities = data.map(univ => ({
            name: univ.name,
            position: new kakao.maps.LatLng(univ.latitude, univ.longitude),
            imageUrl: univ.imageUrl,
          }));
          setUniversities(mappedUniversities);
          initMap(mappedUniversities);
        });
    };

    // Kakao 지도 API 로드
    if (window.kakao && window.kakao.maps) {
      // 이미 로드된 경우: 지도만 다시 초기화
      fetchDataAndInitMap();
    } else {
      // 아직 로드되지 않은 경우: script 추가 후 로드
      if (!document.querySelector(`script[src="//dapi.kakao.com/v2/maps/sdk.js?appkey=d52daa1c41c07f80810fbc61eca944d3&autoload=false"]`)) {
        const script = document.createElement('script');
        script.src = '//dapi.kakao.com/v2/maps/sdk.js?appkey=d52daa1c41c07f80810fbc61eca944d3&autoload=false';
        script.async = true;

        script.onload = () => {
          window.kakao.maps.load(() => {
            fetchDataAndInitMap();
          });
        };
        document.head.appendChild(script);
      }
    }
  }, []);

  return (
    <div style={{ position: "relative", height: "700px" }}>
      <div style={{ width: "520px", display: "flex", justifyContent: "flex-end" }}>
        <h2 style={{ paddingTop: "50px" }}>캠퍼스 위치</h2>
      </div>
      <div
        id="map"
        style={{
          width: '600px',
          height: '500px',
          border: "1px solid #000",
          borderRadius: "20px",
          position: "absolute",
          top: "120px",
          left: "400px"
        }}
      ></div>
    </div>
  );
}

export default Location;
