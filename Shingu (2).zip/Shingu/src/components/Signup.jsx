import { useState } from "react";

export default function Signup() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch("https://jsonplaceholder.typicode.com/posts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });

      if (response.ok) {
        alert("회원가입 성공!");
      } else {
        alert("회원가입 실패!");
      }
    } catch (error) {
      console.error("에러 발생:", error);
      alert("에러 발생!");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
        <h2 className="text-2xl font-bold mb-6 text-center text-green-600">회원가입</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input type="email" placeholder="이메일" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-400" required />
          <input type="password" placeholder="비밀번호" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-green-400" required />
          <button type="submit" className="w-full bg-green-500 text-white py-2 rounded-md hover:bg-green-600 transition">회원가입</button>
        </form>
        <p className="mt-4 text-sm text-center">
          이미 계정이 있으신가요?{" "}
          <a href="/" className="text-green-500 hover:underline">로그인</a>
        </p>
      </div>
    </div>
  );
}
