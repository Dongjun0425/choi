export default function Login() {
  return (
    <div>로그인 페이지 (임시)</div>
  );
}
