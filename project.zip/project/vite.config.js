// vite.config.js
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      '/api/finances': {
        target: 'http://openapi.academyinfo.go.kr',
        changeOrigin: true,
        rewrite: path =>
          path.replace(/^\/api\/finances/, '/openapi/service/rest/FinancesService'),
      },
      '/api/student': {
        target: 'http://openapi.academyinfo.go.kr',
        changeOrigin: true,
        rewrite: path =>
          path.replace(/^\/api\/student/, '/openapi/service/rest/StudentService'),
      },
      // ✅ 추가된 부분
      '/api/school': {
        target: 'http://openapi.academyinfo.go.kr',
        changeOrigin: true,
        rewrite: path =>
          path.replace(/^\/api\/school/, '/openapi/service/rest/SchoolInfoService'),
      },
    },
  },
});
