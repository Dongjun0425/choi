
import React, { useState, useEffect } from 'react';
import reactLogo from './assets/react.svg'
import { useNavigate } from 'react-router-dom'
import viteLogo from '/vite.svg'
import './App.css'
import './Home.jsx'

function Location() {
  useEffect(() => {
    if (!document.querySelector(`script[src="//dapi.kakao.com/v2/maps/sdk.js?appkey=d52daa1c41c07f80810fbc61eca944d3&autoload=false"]`)) {
      const script = document.createElement('script');
      script.src = '//dapi.kakao.com/v2/maps/sdk.js?appkey=d52daa1c41c07f80810fbc61eca944d3&autoload=false';
      script.async = true;
  
      script.onload = () => {
        window.kakao.maps.load(() => {
          const container = document.getElementById('map');
          const options = {
            center: new kakao.maps.LatLng(37.448868, 127.167653),
            level: 3,
          };
          const map = new kakao.maps.Map(container, options);
  
          const universities = [
            { name: "신구대학교(전문대)", position: new kakao.maps.LatLng(37.448868, 127.167653) },
            { name: "서울대학교(4년제)", position: new kakao.maps.LatLng(37.460678, 126.950553) },
            { name: "연세대학교(4년제)", position: new kakao.maps.LatLng(37.566536, 126.936885) },
          ];
  
          const infowindows = [];
  
          universities.forEach(university => {
            const marker = new kakao.maps.Marker({ position: university.position });
            marker.setMap(map);
  
            const infowindow = new kakao.maps.InfoWindow({
              content: `<div style="padding:5px; font-size:14px;">${university.name}</div>`,
            });
            infowindows.push(infowindow);
  
            window.kakao.maps.event.addListener(marker, 'click', function () {
              infowindows.forEach(info => info.close());
              infowindow.open(map, marker);
            });
          });
  
          window.kakao.maps.event.addListener(map, 'click', function () {
            infowindows.forEach(info => info.close());
          });
        });
      };
  
      document.head.appendChild(script);
    }
  }, []);
  
  return (
    <div style={{
        position : "relative",
        height :"700px"
    }}>
      <div style={{
        width : "520px",
        display : "flex",
        justifyContent : "flex-end"
      }}>
        <h2 style={{
          paddingTop : "50px"
        }}>캠퍼스 위치</h2>
      </div>

    <div id="map" style={{
      width: '600px',
      height: '500px',
      border : "1px solid #000",
      borderRadius : "20px",
      position : "absolute",
      top : "120px",
      left : "400px"}}></div>
    
    </div>
  );
}

export default Location;
  