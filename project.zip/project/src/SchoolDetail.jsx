import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { XMLParser } from 'fast-xml-parser';
import {
  Chart as ChartJS,
  BarElement,
  ArcElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
} from 'chart.js';
import { Bar, Pie } from 'react-chartjs-2';
// 이미지 import
import eastSeoul from './img/eastSeoul.jpg';
import eulji from './img/eulji.jpg';
import gachon from './img/gachon.jpg';
import ict from './img/ict.jpg';
import shingu from './img/shingu.jpg';
import yongin from './img/yongin.jpg';

ChartJS.register(CategoryScale, LinearScale, BarElement, ArcElement, Tooltip, Legend);

const schoolData = {
  shingu: { name: "신구대학교", location: "성남시", rating: 3.1, img: shingu },
  yongin: { name: "용인대학교", location: "용인시", rating: 3.7, img: yongin },
  eastSeoul: { name: "동서울대학교", location: "성남시", rating: 3.5, img: eastSeoul },
  eulji: { name: "을지대학교", location: "성남시", rating: 3.1, img: eulji },
  ict: { name: "ICT폴리텍대학", location: "광주시", rating: 3.8, img: ict },
  gachon: { name: "가천대학교", location: "성남시", rating: 3.4, img: gachon },
};

const schoolIdMap = {
  shingu: '0000501',
  yongin: '0000156',
  eastSeoul: '0000450',
  eulji: '0000161',
  gachon: '0000063',
  ict: '0000579',
};

const tabNames = {
  news: '학교정보',
  review: '졸업생 리뷰',
  tuition: '등록금',
  scholarship: '장학금'
};

const SchoolDetail = () => {
  const { schoolId } = useParams();
  const school = schoolData[schoolId];
  const schlCode = schoolIdMap[schoolId];

  const [tab, setTab] = useState("news");
  const [tuitionByYear, setTuitionByYear] = useState({});
  const [scholarshipByYear, setScholarshipByYear] = useState({});
  const [admissionRate, setAdmissionRate] = useState("데이터 없음");
  const [enrolledRate, setEnrolledRate] = useState("데이터 없음");
  const [leaveRate, setLeaveRate] = useState("데이터 없음");
  const [freshmanChartData, setFreshmanChartData] = useState(null);
  const [graduateChartData, setGraduateChartData] = useState(null);
  const [schoolDetail, setSchoolDetail] = useState(null);

  const serviceKey = 'vdCZUaw0OvQ9OVGqD6P9+15oBKd6n/rVlXWRTS2Sj6uoLcYjEUsNBBZ5o7RJiCjWrTKezCptYyNzCOGJlUZSHg==';
  const parser = new XMLParser({ ignoreAttributes: false });

  useEffect(() => {
    if (!schlCode || !school) return;

    const fetchSchoolInfo = async () => {
      try {
        const res = await axios.get(`/api/school/getSchoolInfo`, {
          params: {
            serviceKey,
            svyYr: 2023,
            schlKrnNm: school.name,
            pageNo: 1,
            numOfRows: 10
          },
          responseType: 'text',
          headers: { Accept: 'application/xml' }
        });
        const parsed = parser.parse(res.data);
        setSchoolDetail(parsed?.response?.body?.items?.item || null);
      } catch (err) {
        console.error("학교 기본 정보 API 오류", err);
      }
    };

    const fetchYearlyData = async () => {
      const years = [2022, 2023, 2024];
      const tuition = {};
      const scholarship = {};

      for (const year of years) {
        try {
          const [tRes, sRes] = await Promise.all([
            axios.get('/api/finances/getComparisonTuitionCrntSt', {
              params: { serviceKey, svyYr: year, schlId: schlCode, pageNo: 1 },
              responseType: 'text', headers: { Accept: 'application/xml' }
            }),
            axios.get('/api/finances/getComparisonScholarshipBenefitCrntSt', {
              params: { serviceKey, svyYr: year, schlId: schlCode, pageNo: 1 },
              responseType: 'text', headers: { Accept: 'application/xml' }
            })
          ]);
          tuition[year] = parseInt(parser.parse(tRes.data)?.response?.body?.items?.item?.indctVal1) || null;
          scholarship[year] = parseInt(parser.parse(sRes.data)?.response?.body?.items?.item?.indctVal1) || null;
        } catch (err) {
          console.error(`${year}년 등록금/장학금 API 오류`, err);
        }
      }

      setTuitionByYear(tuition);
      setScholarshipByYear(scholarship);
    };

    const fetchSingleStat = async (endpoint, setter) => {
      try {
        const res = await axios.get(endpoint, {
          params: { serviceKey, svyYr: 2023, schlId: schlCode, pageNo: 1 },
          responseType: 'text',
          headers: { Accept: 'application/xml' }
        });
        const val = parser.parse(res.data)?.response?.body?.items?.item?.indctVal1;
        setter(val || "데이터 없음");
      } catch {
        setter("데이터 없음");
      }
    };

    const fetchPieData = () => {
      fetchSingleStat('/api/student/getComparisonEntranceModelLastRegistrationRatio', setAdmissionRate);
      fetchSingleStat('/api/student/getComparisonEnrolledStudentEnsureRate', setEnrolledRate);
      
    };

    const fetchBottomCharts = async () => {
      try {
        const [freshmanRes, graduateRes] = await Promise.all([
          axios.get('/api/student/getRegionalInsideFixedNumberFreshmanCompetitionRate', {
            params: { serviceKey, svyYr: 2023, schlId: schlCode, pageNo: 1 },
            responseType: 'text', headers: { Accept: 'application/xml' }
          }),
          axios.get('/api/student/getRegionalGraduateEnterFindJobCrntSt', {
            params: { serviceKey, svyYr: 2023, schlId: schlCode, pageNo: 1 },
            responseType: 'text', headers: { Accept: 'application/xml' }
          }),
          axios.get('/api/student/getComparisonStudentOnALeaveOfAbsence', {
            params: { serviceKey, svyYr: 2023, schlId: schlCode, pageNo: 1 },
            responseType: 'text', headers: { Accept: 'application/xml' }
          })
        ]);

        const freshmanData = parser.parse(freshmanRes.data)?.response?.body?.items?.item;
        const graduateData = parser.parse(graduateRes.data)?.response?.body?.items?.item;

        if (Array.isArray(freshmanData)) {
          const 수도권 = freshmanData.find(i => i.znNm === "수도권");
          if (수도권) {
            setFreshmanChartData({
              labels: ['2022', '2023', '2024'],
              values: [
                parseFloat(수도권.indctFirstVal),
                parseFloat(수도권.indctSecondVal),
                parseFloat(수도권.indctThirdVal)
              ]
            });
          }
        }

        if (Array.isArray(graduateData)) {
          const 경기 = graduateData.find(i => i.ctpvNm === "경기" || i.fieldVal7 === "경기");
          if (경기) {
            setGraduateChartData({
              labels: ['2022', '2023', '2024'],
              values: [
                parseFloat(경기.indctFirstVal || 경기.fieldVal4),
                parseFloat(경기.indctSecondVal || 경기.fieldVal5),
                parseFloat(경기.indctThirdVal || 경기.fieldVal6)
              ]
            });
          }
        }
      } catch (err) {
        console.error("하단 차트 API 오류", err);
      }
    };

    fetchSchoolInfo();
    fetchYearlyData();
    fetchPieData();
    fetchBottomCharts();
  }, [schoolId]);

  const renderBarChart = (title, dataMap) => {
    const labels = Object.keys(dataMap);
    const values = Object.values(dataMap);
    return (
      <div style={{ backgroundColor: "#f8f8f8", borderRadius: "20px", padding: "20px" }}>
        <h3>{title}</h3>
        <Bar data={{ labels, datasets: [{ label: title, data: values, backgroundColor: '#4CAF50' }] }}
          options={{ responsive: true, scales: { y: { beginAtZero: true } } }} />
      </div>
    );
  };

  const renderPieChart = (label, valueStr) => {
    const value = parseFloat(valueStr);
    if (isNaN(value)) return <p>{valueStr}</p>;
    return (
      <div style={{ width: '100%', height: '200px', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <div style={{ width: '100%', height: '150px' }}>
          <Pie data={{
            labels: [label, '기타'],
            datasets: [{ data: [value, 100 - value], backgroundColor: ['#4CAF50', '#eee'], borderWidth: 1 }]
          }} options={{ responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false } } }} />
        </div>
        <p style={{ fontWeight: 'bold', marginTop: '8px', fontSize: '15px', textAlign: 'center' }}>{label}</p>
      </div>
    );
  };

  const renderStatBox = (title, chartData) => (
    <div style={{
      width: "30%", minWidth: "250px", border: "1px solid #ccc",
      borderRadius: "10px", padding: "15px", backgroundColor: "#fff"
    }}>
      <strong>{title}</strong>
      {chartData ? (
        <Bar data={{ labels: chartData.labels, datasets: [{ label: title, data: chartData.values, backgroundColor: '#4CAF50' }] }}
          options={{ responsive: true, scales: { y: { beginAtZero: true } } }} />
      ) : <p>데이터 없음</p>}
    </div>
  );

  if (!school) return <div>학교 정보를 찾을 수 없습니다.</div>;

  return (
    <div style={{ padding: "40px", fontFamily: "sans-serif" }}>
      <div style={{ display: "flex", gap: "40px", fontWeight: "bold", marginBottom: "20px", cursor: "pointer" }}>
        {Object.entries(tabNames).map(([key, label]) => (
          <span key={key} style={tab === key ? { color: "green", borderBottom: "2px solid green" } : {}}
            onClick={() => setTab(key)}>{label}</span>
        ))}
      </div>

      {tab === "news" && (
  <div style={{
    backgroundColor: "#f8f8f8",
    padding: "20px",
    borderRadius: "20px",
    display: "flex",
    gap: "30px"
  }}>
    {/* 왼쪽 이미지 */}
<div style={{ flex: "0 0 250px" }}>
  <img
    src={school.img}
    alt={school.name}
    style={{ width: "200%", height: "auto", borderRadius: "15px" }}
  />
</div>

{/* 중앙: 학교 정보 */}
<div style={{ flex: 2, textAlign: "left" }}>
  {schoolDetail ? (
    <ul style={{
      listStyle: "none",
      padding: 0,
      marginLeft: 0,
      lineHeight: "1.8",
      textAlign: "left"
    }}>
      <li><strong>설립유형:</strong> {schoolDetail.schlEstbDivNm}</li>
      <li><strong>학교유형:</strong> {schoolDetail.schlDivNm}</li>
      <li><strong>설립연도:</strong> {schoolDetail.schlEstbDt}년</li>
      <li><strong>주소:</strong> {schoolDetail.postNoAdrs}</li>
      <li><strong>우편번호:</strong> {schoolDetail.postNo}</li>
      <li><strong>전화번호:</strong> {schoolDetail.schlRepTpNoCtnt}</li>
      <li><strong>팩스번호:</strong> {schoolDetail.schlRepFxNoCtnt}</li>
      <li><strong>홈페이지:</strong> <a href={schoolDetail.schlUrlAdrs} target="_blank" rel="noreferrer">{schoolDetail.schlUrlAdrs}</a></li>
    </ul>
  ) : (
    <p>학교 정보를 불러오는 중입니다...</p>
  )}
</div>


    {/* 오른쪽: 차트 3개 세로로 배치 */}
    <div style={{
      flex: "0 0 200px",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      gap: "20px"
    }}>
      {renderPieChart("입학전형 등록률", admissionRate)}
      {renderPieChart("재학생 충원율", enrolledRate)}
      
    </div>
  </div>
)}

      {tab === "review" && <div>졸업생 리뷰 내용입니다.</div>}
      {tab === "tuition" && renderBarChart("연도별 등록금", tuitionByYear)}
      {tab === "scholarship" && renderBarChart("연도별 장학금 수혜", scholarshipByYear)}

      <div style={{
        display: "flex", flexWrap: "wrap", marginTop: "30px",
        gap: "10px", padding: "20px", backgroundColor: "#f8f8f8", borderRadius: "20px"
      }}>
        {renderStatBox("통계 항목 1: 신입생 경쟁률", freshmanChartData)}
        {renderStatBox("통계 항목 2: 졸업생 진학/취업", graduateChartData)}
        {renderStatBox("통계 항목 3: 휴학생비율",leaveRate)}
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} style={{
            width: "30%", minWidth: "250px", border: "1px solid #ccc",
            borderRadius: "10px", padding: "15px", backgroundColor: "#fff"
          }}>
            <strong>통계 항목 {i + 4}</strong>
            <p style={{ fontSize: "13px", color: "#777" }}>데이터는 추후 삽입 예정</p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default SchoolDetail;
