import React from 'react'
import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './Ranking.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <h1 className="text-3xl font-bold underline italic">Vite + React</h1>
    <h2 className="italic">Sans 폰트</h2>
    </>
  )
}

export default Ranking