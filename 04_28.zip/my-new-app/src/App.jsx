import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home from './Home';
import Signup from './Signup';
import Login from './Login';
import Location from './Location';
import News from './News';
import AnnouncementDetail from './AnnouncementDetail'; // 공지사항 상세 페이지

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />
        <Route path="/location" element={<Location />} />
        <Route path="/news" element={<News />} />
        <Route path="/announcement/:id" element={<AnnouncementDetail />} />
      </Routes>
    </Router>
  );
}

export default App;